"""
Bitcoin Relay - Personal Bitcoin Privacy Tool
Relay Bitcoin through multiple addresses with Fibonacci-paced timing delays.
"""

__version__ = "1.1.0"
