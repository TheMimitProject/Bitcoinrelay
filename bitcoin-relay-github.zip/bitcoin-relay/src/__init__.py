"""
Bitcoin Relay - Personal Bitcoin Privacy Tool

A self-hosted tool for relaying Bitcoin through multiple addresses
with Fibonacci-paced timing delays.
"""

__version__ = "1.0.0"
__author__ = "Your Name"
