# Dashboard Preview Image

This directory should contain screenshots for the README.

To add the dashboard preview:
1. Run the application
2. Take a screenshot of the dashboard
3. Save it as `dashboard-preview.png` in this directory

Recommended image size: 1200x800 pixels
